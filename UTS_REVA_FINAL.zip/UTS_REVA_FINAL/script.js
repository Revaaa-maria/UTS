
const themeBtn = document.getElementById('themeBtn');
const body = document.body;

themeBtn.addEventListener('click', ()=>{
    body.classList.toggle('light');

    if(body.classList.contains('light')){
        themeBtn.textContent = 'Dark Mode';
    }else{
        themeBtn.textContent = 'Light Mode';
    }
});

const words = [
    'Mahasiswa Sistem Informasi',
    'UI/UX Enthusiast',
    'Web Developer'
];

let i = 0;
let j = 0;
let currentWord = '';
let isDeleting = false;

function type(){
    currentWord = words[i];

    if(isDeleting){
        j--;
    }else{
        j++;
    }

    document.getElementById('typing').textContent = currentWord.substring(0,j);

    if(!isDeleting && j === currentWord.length){
        isDeleting = true;
        setTimeout(type,1000);
        return;
    }

    if(isDeleting && j === 0){
        isDeleting = false;
        i = (i+1)%words.length;
    }

    setTimeout(type,isDeleting ? 50 : 100);
}

type();

const hamburger = document.getElementById('hamburger');
const navMenu = document.getElementById('nav-menu');

hamburger.addEventListener('click', ()=>{
    navMenu.classList.toggle('active');
});
